package repasoGeneral2;

public class RecursivoPalidromo {
	
	public static boolean esPolidromo(String palabra, int i) {
		if(i<(palabra.length()/2)) {
			if (palabra.substring(i, i+1).equals(palabra.substring(palabra.length()-(1+i), palabra.length()-i))) {
				return true;
			} else {
				return esPolidromo(palabra, i+1);
			}
		} else {
			return false;
		}
		
	}
	
	public static void main(String[] args) {
		String palabra = "abcyj";
		int i = 0;
		boolean respuesta = esPolidromo(palabra, i);
		if(respuesta) {
			System.out.println("La cadena " + palabra + " es un pol�dromo");
		} else {
			System.out.println("La cadena " + palabra + " NO es un pol�dromo");
		}
	}

}
